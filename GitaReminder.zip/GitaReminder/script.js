// let shloka = document.querySelector("#shloka");
// let verse = document.querySelector("#verse");
// let translation = document.querySelector("#translation");
// let summary = document.querySelector("#summary");

let api_url = "https://vedicscriptures.github.io/chapters";

// fetch(api_url)
//     .then(res => res.json())
//     .then(data => {
//         shloka.innerHTML = '"' + data.chapter_number + '"';
//         verse.innerHTML = "-" + data.verses_count +'"';
//         translation.innerHTML = "-" + data.translation +'"';
//         summary.innerHTML = "-" + data.summary +'"';

//     });
console.log(document.getElementById("gitaDislay"));

    // fetch(api_url)
    // .then(response => response.json())
    // .then(data => console.log(data));
    fetch(api_url)
    
    .then(res => res.json())
    .then(data => {
   
        
    const dataDisplay = document.getElementById("gitaDisplay");
    // Create HTML elements to display the JSON data
    const chpElement = document.createElement("p");
    chpElement.textContent = "ChapterNumber: " + data.chapter_number;

    const verseElement = document.createElement("p");
    verseElement.textContent = "VerseCount: " + data.verses_count;

    const translationElement = document.createElement("p");
    translationElement.textContent = "Translation: " + data.translation;

    const summaryElement = document.createElement("p");
    summaryElement.textContent = "Summary: " + data.en;

    // Append the elements to the "dataDisplay" div
    dataDisplay.appendChild(chpElement);
    dataDisplay.appendChild(verseElement);
    dataDisplay.appendChild(translationElement);
    dataDisplay.appendChild(summaryElement);
    console.log(data)
})
.catch(error => console.error("Error fetching JSON data:", error));